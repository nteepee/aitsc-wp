main.c is the receiver module code.
transmitter.c is the transmitter module code.
DisplayV9/ folder contains the esp32 display code